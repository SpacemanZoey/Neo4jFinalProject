#!/usr/bin/env python
# -*- coding: utf-8 -*-

RETURN_JSON = "return json data"
RETURE_HTML = "return html data"